//+build !linux,!windows

package main

var processor int32

// TODO
func threadaffinity() {

}
