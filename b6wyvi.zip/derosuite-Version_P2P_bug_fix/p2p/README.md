This is the basic design of the V2 protocol which features  quite a lot of flexibility and easy up-gradation



The protocol is planned to be complete SSL/TLS based to avoid mass traffic analysis by any one.



This is work-in-progress 