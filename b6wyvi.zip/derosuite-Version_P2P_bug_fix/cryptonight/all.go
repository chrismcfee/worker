// +build !amd64

package cryptonight

// empty function to satisfy
func encryptAESRound(xk *uint32, dst, src *uint32) {

}

func encrypt10AESRound(xk *uint32, dst, src *uint32) {

}
