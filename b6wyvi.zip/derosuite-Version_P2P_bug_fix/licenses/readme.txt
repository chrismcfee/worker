This folder contains licenses of other libraries used within the project 

